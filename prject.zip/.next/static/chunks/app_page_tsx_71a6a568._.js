(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_locomotive-scroll_dist_locomotive-scroll_esm_6b6ebcc8.js",
  "static/chunks/_76cfe858._.js",
  "static/chunks/node_modules_locomotive-scroll_dist_locomotive-scroll_2e6b89f7.css"
],
    source: "dynamic"
});
