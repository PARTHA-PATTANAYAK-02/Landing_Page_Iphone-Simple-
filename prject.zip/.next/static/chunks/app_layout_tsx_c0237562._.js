(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_83dc72a7._.js",
  "static/chunks/_ec620231._.js",
  "static/chunks/app_globals_73c37791.css"
],
    source: "dynamic"
});
