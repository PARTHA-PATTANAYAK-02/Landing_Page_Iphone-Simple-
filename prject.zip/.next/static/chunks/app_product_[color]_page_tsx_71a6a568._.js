(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_f5074bf6._.js",
  "static/chunks/app_product_[color]_page_tsx_2d088bcc._.js"
],
    source: "dynamic"
});
