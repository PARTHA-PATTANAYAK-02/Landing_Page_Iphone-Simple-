declare module "locomotive-scroll";
